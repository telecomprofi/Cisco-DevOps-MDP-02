firstName = input("What is your first name? ")
lastName = input("What is your last name? ")
location = input("What is your location? ")
age = input("What is your age? ")
space = " "
print("Hi " + firstName + space + lastName + "! Your location is " +
      location + " and you are " + age + " years old.")
"""
OUTPUT
========== RESTART: /home/allan/Dropbox/ETW-BP/personal-info_sol.py ==========
What is your first name? First
What is your last name? Last
What is your location? Texas
What is your age? 54
Hi First Last! Your location is Texas and you are 54 years old.
>>>
"""
